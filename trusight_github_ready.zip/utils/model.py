def load_model():
    # Dummy placeholder
    return None
