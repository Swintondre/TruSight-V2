# Placeholder for future integration with mistral-based local LLMs
def llm_judgment(claim, sources):
    return {
        "score": 50,
        "explanation": "LLM scoring module not yet implemented."
    }
